const firebaseConfig = {
  apiKey: "AIzaSyBdmS7jYtdcYqjJjYceJn833kibluJHD-I",
  authDomain: "clientformapp-6dcd7.firebaseapp.com",
  projectId: "clientformapp-6dcd7",
  storageBucket: "clientformapp-6dcd7.firebasestorage.app",
  messagingSenderId: "83790347145",
  appId: "1:83790347145:web:f7f2f3460b4a65c1a4ff58"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
